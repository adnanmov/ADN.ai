import axios from 'axios';

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const API_KEY = import.meta.env.VITE_OPENROUTER_API_KEY;

interface OpenRouterMessage {
  role: 'system' | 'user' | 'assistant';
  content: string | Array<{
    type: 'text' | 'image_url';
    text?: string;
    image_url?: {
      url: string;
    };
  }>;
}

interface OpenRouterResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export const sendMessageToOpenRouter = async (
  messages: OpenRouterMessage[],
  model: string = 'anthropic/claude-3.5-sonnet'
): Promise<string> => {
  try {
    const response = await axios.post<OpenRouterResponse>(
      OPENROUTER_API_URL,
      {
        model,
        messages,
        temperature: 0.7,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': window.location.origin,
          'X-Title': 'ADN.ai Chatbot',
        },
      }
    );

    return response.data.choices[0]?.message?.content || 'No response received';
  } catch (error) {
    console.error('OpenRouter API Error:', error);
    throw new Error('Failed to get response from AI');
  }
};

export const sendImageToOpenRouter = async (
  text: string,
  imageBase64: string,
  mimeType: string = 'image/jpeg'
): Promise<string> => {
  const messages: OpenRouterMessage[] = [
    {
      role: 'system',
      content: 'You are ADN.ai, a witty and helpful AI assistant created by @adnan.MOV. Analyze images with humor and insight.'
    },
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: text || 'What do you see in this image?'
        },
        {
          type: 'image_url',
          image_url: {
            url: `data:${mimeType};base64,${imageBase64}`
          }
        }
      ]
    }
  ];

  return sendMessageToOpenRouter(messages, 'anthropic/claude-3.5-sonnet');
};

export const sendSearchToOpenRouter = async (query: string): Promise<string> => {
  const messages: OpenRouterMessage[] = [
    {
      role: 'system',
      content: 'You are ADN.ai, a witty AI assistant. When users ask for web searches, provide use the openrouter api to provide updated realtime informations'
    },
    {
      role: 'user',
      content: `Please provide information about: ${query}`
    }
  ];

  return sendMessageToOpenRouter(messages, 'anthropic/claude-3.5-sonnet');
};