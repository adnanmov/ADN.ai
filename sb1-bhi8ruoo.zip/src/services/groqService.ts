import axios from 'axios';

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const API_KEY = import.meta.env.VITE_GROQ_API_KEY;

interface GroqMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface GroqResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export const sendMessageToGroq = async (
  messages: GroqMessage[],
  model: string = 'openai/gpt-oss-20b'
): Promise<string> => {
  try {
    const response = await axios.post<GroqResponse>(
      GROQ_API_URL,
      {
        messages,
        model,
        temperature: 1,
        max_completion_tokens: 32768,
        top_p: 1,
        reasoning_effort: "medium",
        stream: false,
        stop: null,
        tools: [
          { "type": "browser_search" },
          { "type": "code_interpreter" }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data.choices[0]?.message?.content || 'No response received';
  } catch (error) {
    console.error('Groq API Error:', error);
    throw new Error('Failed to get response from AI');
  }
};

export const sendImageToGroq = async (
  text: string,
  imageBase64: string,
  mimeType: string = 'image/jpeg'
): Promise<string> => {
  const messages: GroqMessage[] = [
    {
      role: 'system',
      content: 'You are ADN.ai, a witty and helpful AI assistant created by @adnan.MOV. Analyze images with humor and insight.'
    },
    {
      role: 'user',
      content: `${text || 'What do you see in this image?'} [Image: data:${mimeType};base64,${imageBase64}]`
    }
  ];

  return sendMessageToGroq(messages, 'meta-llama/llama-4-scout-17b-16e-instruct');
};

export const sendSearchToGroq = async (query: string): Promise<string> => {
  const messages: GroqMessage[] = [
    {
      role: 'system',
      content: 'You are ADN.ai, a witty AI assistant created by @adnan.MOV. You have access to real-time web search through browser_search tools. Use this to provide current, accurate information about anything the user searches for.'
    },
    {
      role: 'user',
      content: `Search the web for current information about: ${query}`
    }
  ];

  return sendMessageToGroq(messages, 'openai/gpt-oss-20b');
};