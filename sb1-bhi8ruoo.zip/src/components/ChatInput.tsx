import React, { useState, KeyboardEvent } from 'react';
import { Send, Image, Link, Search, Plus, X } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onSendImage: (message: string, imageData: string, imageType: 'upload' | 'url') => void;
  onSendSearch: (query: string) => void;
  disabled?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  onSendImage, 
  onSendSearch, 
  disabled = false 
}) => {
  const [message, setMessage] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMode, setActiveMode] = useState<'text' | 'image' | 'url' | 'search'>('text');
  const [showOptions, setShowOptions] = useState(false);

  const handleSend = () => {
    if (activeMode === 'text' && message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
    } else if (activeMode === 'url' && imageUrl.trim() && !disabled) {
      onSendImage(message.trim() || 'Analyze this image', imageUrl.trim(), 'url');
      setMessage('');
      setImageUrl('');
      setActiveMode('text');
    } else if (activeMode === 'search' && searchQuery.trim() && !disabled) {
      onSendSearch(searchQuery.trim());
      setSearchQuery('');
      setActiveMode('text');
      setShowOptions(false);
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && !disabled) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        onSendImage(message.trim() || 'Analyze this image', base64, 'upload');
        setMessage('');
        setActiveMode('text');
        setShowOptions(false);
      };
      reader.readAsDataURL(file);
    }
    // Reset the input
    event.target.value = '';
  };

  const handleModeSelect = (mode: 'text' | 'image' | 'url' | 'search') => {
    setActiveMode(mode);
    setShowOptions(false);
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const renderInput = () => {
    switch (activeMode) {
      case 'url':
        return (
          <>
            <input
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Enter image URL..."
              className="w-full px-4 py-3 pr-12 bg-white border border-white rounded-full text-black placeholder-gray-500 focus:outline-none focus:border-white transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)] focus:shadow-[0_0_40px_rgba(255,255,255,0.5)] animate-input-glow"
              disabled={disabled}
            />
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Optional: Add a message about the image..."
              className="w-full px-4 py-3 pr-12 bg-white border border-white rounded-full text-black placeholder-gray-500 focus:outline-none focus:border-white transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)] focus:shadow-[0_0_40px_rgba(255,255,255,0.5)] animate-input-glow mt-2"
              disabled={disabled}
            />
          </>
        );
      case 'search':
        return (
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Enter search query..."
            className="w-full px-4 py-3 pr-12 bg-white border border-white rounded-full text-black placeholder-gray-500 focus:outline-none focus:border-white transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)] focus:shadow-[0_0_40px_rgba(255,255,255,0.5)] animate-input-glow"
            disabled={disabled}
          />
        );
      default:
        return (
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="w-full px-4 py-3 pr-12 bg-white border border-white rounded-full text-black placeholder-gray-500 focus:outline-none focus:border-white transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)] focus:shadow-[0_0_40px_rgba(255,255,255,0.5)] animate-input-glow"
            disabled={disabled}
          />
        );
    }
  };
  return (
    <div className="p-4 border-t border-gray-800 animate-slide-up">
      <div className="flex items-center gap-3 max-w-4xl mx-auto animate-bounce-in">
        {/* Single Expandable Button */}
        <div className="relative">
          <button
            onClick={() => setShowOptions(!showOptions)}
            className="p-3 rounded-full bg-white text-black transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.5)] hover:shadow-[0_0_40px_rgba(255,255,255,0.7)] animate-glow-pulse hover:scale-110"
            disabled={disabled}
            title="Options"
          >
            {showOptions ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          </button>
          
          {/* Expandable Options */}
          {showOptions && (
            <div className="absolute bottom-full left-0 mb-2 flex flex-col gap-2 animate-slide-up">
              <button
                onClick={() => handleModeSelect('text')}
                className={`p-2 rounded-full transition-all duration-300 ${
                  activeMode === 'text' 
                    ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.5)]' 
                    : 'bg-gray-800 text-white hover:bg-gray-700'
                } hover:scale-110`}
                disabled={disabled}
                title="Text message"
              >
                <Send className="w-4 h-4" />
              </button>
              
              <label className={`p-2 rounded-full cursor-pointer transition-all duration-300 ${
                activeMode === 'image' 
                  ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.5)]' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              } hover:scale-110`} title="Upload image">
                <Image className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={disabled}
                />
              </label>
              
              <button
                onClick={() => handleModeSelect('url')}
                className={`p-2 rounded-full transition-all duration-300 ${
                  activeMode === 'url' 
                    ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.5)]' 
                    : 'bg-gray-800 text-white hover:bg-gray-700'
                } hover:scale-110`}
                disabled={disabled}
                title="Image from URL"
              >
                <Link className="w-4 h-4" />
              </button>
              
              <button
                onClick={() => handleModeSelect('search')}
                className={`p-2 rounded-full transition-all duration-300 ${
                  activeMode === 'search' 
                    ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.5)]' 
                    : 'bg-gray-800 text-white hover:bg-gray-700'
                } hover:scale-110`}
                disabled={disabled}
                title="Web search"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="flex-1 relative">
          {renderInput()}
          <button
            onClick={handleSend}
            disabled={
              disabled || 
              (activeMode === 'text' && !message.trim()) ||
              (activeMode === 'url' && !imageUrl.trim()) ||
              (activeMode === 'search' && !searchQuery.trim())
            }
            className="absolute right-2 top-1/2 transform -translate-y-1/2 p-2 bg-white text-black rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.4)] hover:shadow-[0_0_40px_rgba(255,255,255,0.6)] hover:animate-pulse"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {/* Mode indicator */}
      {activeMode !== 'text' && (
        <div className="text-center mt-2">
          <span className="text-xs text-gray-400">
            {activeMode === 'url' && 'Image URL mode - Enter image URL and optional message'}
            {activeMode === 'search' && 'Search mode - Enter your search query'}
          </span>
          <button
            onClick={() => setActiveMode('text')}
            className="ml-2 text-xs text-white hover:text-gray-300 underline"
            onClick={() => {
              setActiveMode('text');
              setShowOptions(false);
            }}
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
};