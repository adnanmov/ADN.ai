import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ChatMessageProps {
  message: string;
  isBot: boolean;
  timestamp: Date;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isBot, timestamp }) => {
  return (
    <div className={`flex mb-6 ${isBot ? 'justify-start animate-slide-in-left' : 'justify-end animate-slide-in-right'}`}>
      <div className={`max-w-[85%] sm:max-w-[80%] ${isBot ? '' : 'order-1'}`}>
        <div
          className={`px-4 py-3 rounded-2xl ${
            isBot
              ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.3)] border border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] animate-glow-pulse hover:scale-105 transition-all duration-300'
              : 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.4)] border border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.6)] animate-glow-pulse hover:scale-105 transition-all duration-300'
          }`}
        >
          <div className="text-sm leading-relaxed prose prose-sm max-w-none prose-invert break-words overflow-wrap-anywhere">
            <ReactMarkdown 
              remarkPlugins={[remarkGfm]}
              components={{
                p: ({ children }) => <p className="mb-2 last:mb-0 break-words">{children}</p>,
                strong: ({ children }) => <strong className="font-bold text-black">{children}</strong>,
                em: ({ children }) => <em className="italic">{children}</em>,
                code: ({ children }) => <code className="bg-gray-200 px-1 py-0.5 rounded text-xs font-mono text-black break-all">{children}</code>,
                ul: ({ children }) => <ul className="list-disc list-inside mb-2 break-words">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal list-inside mb-2 break-words">{children}</ol>,
                li: ({ children }) => <li className="mb-1 break-words">{children}</li>,
                h1: ({ children }) => <h1 className="text-lg font-bold mb-2 break-words">{children}</h1>,
                h2: ({ children }) => <h2 className="text-base font-bold mb-2 break-words">{children}</h2>,
                h3: ({ children }) => <h3 className="text-sm font-bold mb-1 break-words">{children}</h3>,
              }}
            >
              {message}
            </ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
};