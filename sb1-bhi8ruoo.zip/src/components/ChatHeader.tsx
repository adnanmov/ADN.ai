import React from 'react';

export const ChatHeader: React.FC = () => {
  return (
    <div className="text-center py-8 border-b border-gray-800 animate-fade-in">
      <div className="flex items-center justify-center mb-2">
        <img 
          src="/final header.jpeg" 
          alt="ADN.ai Header" 
          className="h-8 animate-text-glow ml-4"
        />
      </div>
      <p className="text-gray-400 text-sm">
        by{' '}
        <a 
          href="https://instagram.com/adnan.mov" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-gray-300 hover:text-white transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] animate-bounce-subtle"
        >
          @adnan.MOV
        </a>
      </p>
    </div>
  );
};