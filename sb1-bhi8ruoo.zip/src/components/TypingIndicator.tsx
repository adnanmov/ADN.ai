import React from 'react';

export const TypingIndicator: React.FC = () => {
  return (
    <div className="flex mb-6 animate-slide-in-left">
      <div className="bg-gray-800 rounded-2xl px-4 py-3 shadow-[0_0_20px_rgba(255,255,255,0.1)] animate-glow-pulse">
        <div className="flex gap-1">
          <div className="w-2 h-2 bg-white rounded-full animate-bounce shadow-[0_0_10px_rgba(255,255,255,0.5)]" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-white rounded-full animate-bounce shadow-[0_0_10px_rgba(255,255,255,0.5)]" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-white rounded-full animate-bounce shadow-[0_0_10px_rgba(255,255,255,0.5)]" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
};