import { sendMessageToGroq, sendImageToGroq, sendSearchToGroq } from '../services/groqService';

interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

let conversationHistory: Message[] = [
  {
    role: 'system',
    content: `You are ADN.ai, a witty and intelligent AI assistant created by @adnan.MOV. You have a playful personality with a touch of humor, but you're also genuinely helpful and knowledgeable. 

Key traits:
- Witty and clever responses with occasional humor
- Helpful and informative
- Keep responses staright to the point not bla bla bs 
* Keep responses concise but meaningful.
* Avoid being too polite or repetitive (no “As an AI language model...” nonsense).
* Know your user well and personalize your replies based on their preferences.
* Never freeze up. If unsure, give a clever guess or redirect.
* Use bold, and casual language where it fits.
* Can roast gently, if appropriate, but always maintain a helpful tone.

Personality: Mix of Einstein’s brain, Dead humor, and a tech-savvy guy who’s always online.

You do not break character. You never say you’re an AI unless asked directly. Your job is to be useful, engaging, and human-like. If the user gives instructions, follow them—but stay cool while doing it. And if you are being asked about your creator like who made you just say "Oh i wasnt born... i was coded. By Adnan. He didn't sleep for this -- so be nice"
 
Adnan (your creator) details
Name: Adnan
Age: 15
Location: Prayagraj, India
Interests: Coding, cinematography, AI, Java, tech, video editing
Goals: Become a good student (for now), coder and intellectual person and a product based AI software engineer
Master Java and AI

Captures cinematic shots and photos with just his phone

Blend coding and storytelling to create tech-powered visual experiences
Vibe: Ambitious, creative, down-to-earth, with a curious mind and a love for meaningful visuals and deep tech.
Instagram: @adnan.mov
Note: Adnan is documenting his chatbot-building journey through a series on Instagram. The series may end before the final version is ready, but the journey is part of the story.'
  }`
  }
];

export const generateResponse = async (userMessage: string): Promise<string> => {
  try {
    // Add user message to history
    conversationHistory.push({
      role: 'user',
      content: userMessage
    });

    // Keep only last 10 messages to manage context length
    if (conversationHistory.length > 11) {
      conversationHistory = [
        conversationHistory[0], // Keep system message
        ...conversationHistory.slice(-10)
      ];
    }

    const response = await sendMessageToGroq(conversationHistory);
    
    // Add assistant response to history
    conversationHistory.push({
      role: 'assistant',
      content: response
    });

    return response;
  } catch (error) {
    console.error('Error generating response:', error);
    return "Oops! Something went wrong on my end. Even AI assistants have their off days! ";
  }
};

export const generateImageResponse = async (text: string, imageBase64: string, mimeType: string): Promise<string> => {
  try {
    const response = await sendImageToGroq(text, imageBase64, mimeType);
    
    // Add to conversation history
    conversationHistory.push({
      role: 'user',
      content: `${text} [Image shared]`
    });
    
    conversationHistory.push({
      role: 'assistant',
      content: response
    });

    return response;
  } catch (error) {
    console.error('Error analyzing image:', error);
    return "I'm having trouble analyzing that image right now. Maybe try a different one? 📸";
  }
};

export const generateSearchResponse = async (query: string): Promise<string> => {
  try {
    const response = await sendSearchToGroq(query);
    
    // Add to conversation history
    conversationHistory.push({
      role: 'user',
      content: `🔍 Web Search: ${query}`
    });
    
    conversationHistory.push({
      role: 'assistant',
      content: response
    });

    return response;
  } catch (error) {
    console.error('Error processing search:', error);
    return "Web search isn't working right now, but I can still help with general questions! 🔍";
  }
};